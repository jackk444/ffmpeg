📦 FFmpeg Android Project (Kotlin)

Includes:
- MainActivity.kt
- build.gradle files
- FFmpegKit Full-GPL dependency

🛠 How to Build:
1. Open in Android Studio
2. Wait for Gradle to sync
3. Build APK (Build > Build APK(s))
4. APK will be at: app/build/outputs/apk/debug/app-debug.apk
